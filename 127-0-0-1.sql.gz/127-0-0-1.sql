-- Adminer 4.0.3 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = '+00:00';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `wordpress_neu` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `wordpress_neu`;

DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1,	1,	'WordPress先生',	'',	'https://wordpress.org/',	'',	'2014-05-07 05:19:35',	'2014-05-07 05:19:35',	'您好，这是一条评论。\n要删除评论，请先登录，然后再查看这篇文章的评论。登录后您可以看到编辑或者删除评论的选项。',	0,	'1',	'',	'',	0,	0);

DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1,	'siteurl',	'http://localhost/wordpress',	'yes'),
(2,	'blogname',	'test',	'yes'),
(3,	'blogdescription',	'又一个WordPress站点',	'yes'),
(4,	'users_can_register',	'0',	'yes'),
(5,	'admin_email',	'11111@111.com',	'yes'),
(6,	'start_of_week',	'1',	'yes'),
(7,	'use_balanceTags',	'0',	'yes'),
(8,	'use_smilies',	'1',	'yes'),
(9,	'require_name_email',	'1',	'yes'),
(10,	'comments_notify',	'1',	'yes'),
(11,	'posts_per_rss',	'10',	'yes'),
(12,	'rss_use_excerpt',	'0',	'yes'),
(13,	'mailserver_url',	'mail.example.com',	'yes'),
(14,	'mailserver_login',	'login@example.com',	'yes'),
(15,	'mailserver_pass',	'password',	'yes'),
(16,	'mailserver_port',	'110',	'yes'),
(17,	'default_category',	'1',	'yes'),
(18,	'default_comment_status',	'open',	'yes'),
(19,	'default_ping_status',	'open',	'yes'),
(20,	'default_pingback_flag',	'1',	'yes'),
(21,	'posts_per_page',	'10',	'yes'),
(22,	'date_format',	'Y年n月j日',	'yes'),
(23,	'time_format',	'ag:i',	'yes'),
(24,	'links_updated_date_format',	'Y年n月j日ag:i',	'yes'),
(25,	'comment_moderation',	'0',	'yes'),
(26,	'moderation_notify',	'1',	'yes'),
(27,	'permalink_structure',	'',	'yes'),
(28,	'gzipcompression',	'0',	'yes'),
(29,	'hack_file',	'0',	'yes'),
(30,	'blog_charset',	'UTF-8',	'yes'),
(31,	'moderation_keys',	'',	'no'),
(32,	'active_plugins',	'a:0:{}',	'yes'),
(33,	'home',	'http://localhost/wordpress',	'yes'),
(34,	'category_base',	'',	'yes'),
(35,	'ping_sites',	'http://rpc.pingomatic.com/',	'yes'),
(36,	'advanced_edit',	'0',	'yes'),
(37,	'comment_max_links',	'2',	'yes'),
(38,	'gmt_offset',	'0',	'yes'),
(39,	'default_email_category',	'1',	'yes'),
(40,	'recently_edited',	'',	'no'),
(41,	'template',	'twentytwelve',	'yes'),
(42,	'stylesheet',	'twentytwelve',	'yes'),
(43,	'comment_whitelist',	'1',	'yes'),
(44,	'blacklist_keys',	'',	'no'),
(45,	'comment_registration',	'0',	'yes'),
(46,	'html_type',	'text/html',	'yes'),
(47,	'use_trackback',	'0',	'yes'),
(48,	'default_role',	'subscriber',	'yes'),
(49,	'db_version',	'27916',	'yes'),
(50,	'uploads_use_yearmonth_folders',	'1',	'yes'),
(51,	'upload_path',	'',	'yes'),
(52,	'blog_public',	'1',	'yes'),
(53,	'default_link_category',	'2',	'yes'),
(54,	'show_on_front',	'posts',	'yes'),
(55,	'tag_base',	'',	'yes'),
(56,	'show_avatars',	'1',	'yes'),
(57,	'avatar_rating',	'G',	'yes'),
(58,	'upload_url_path',	'',	'yes'),
(59,	'thumbnail_size_w',	'150',	'yes'),
(60,	'thumbnail_size_h',	'150',	'yes'),
(61,	'thumbnail_crop',	'1',	'yes'),
(62,	'medium_size_w',	'300',	'yes'),
(63,	'medium_size_h',	'300',	'yes'),
(64,	'avatar_default',	'mystery',	'yes'),
(65,	'large_size_w',	'1024',	'yes'),
(66,	'large_size_h',	'1024',	'yes'),
(67,	'image_default_link_type',	'file',	'yes'),
(68,	'image_default_size',	'',	'yes'),
(69,	'image_default_align',	'',	'yes'),
(70,	'close_comments_for_old_posts',	'0',	'yes'),
(71,	'close_comments_days_old',	'14',	'yes'),
(72,	'thread_comments',	'1',	'yes'),
(73,	'thread_comments_depth',	'5',	'yes'),
(74,	'page_comments',	'0',	'yes'),
(75,	'comments_per_page',	'50',	'yes'),
(76,	'default_comments_page',	'newest',	'yes'),
(77,	'comment_order',	'asc',	'yes'),
(78,	'sticky_posts',	'a:0:{}',	'yes'),
(79,	'widget_categories',	'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}',	'yes'),
(80,	'widget_text',	'a:0:{}',	'yes'),
(81,	'widget_rss',	'a:0:{}',	'yes'),
(82,	'uninstall_plugins',	'a:0:{}',	'no'),
(83,	'timezone_string',	'Asia/Shanghai',	'yes'),
(84,	'page_for_posts',	'0',	'yes'),
(85,	'page_on_front',	'0',	'yes'),
(86,	'default_post_format',	'0',	'yes'),
(87,	'link_manager_enabled',	'0',	'yes'),
(88,	'initial_db_version',	'27916',	'yes'),
(89,	'wp_user_roles',	'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}',	'yes'),
(90,	'widget_search',	'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}',	'yes'),
(91,	'widget_recent-posts',	'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}',	'yes'),
(92,	'widget_recent-comments',	'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}',	'yes'),
(93,	'widget_archives',	'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}',	'yes'),
(94,	'widget_meta',	'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}',	'yes'),
(95,	'sidebars_widgets',	'a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}s:13:\"array_version\";i:3;}',	'yes'),
(96,	'cron',	'a:5:{i:1399461300;a:1:{s:20:\"wp_maybe_auto_update\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1399483184;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1399526398;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1399526463;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}',	'yes'),
(98,	'_site_transient_update_core',	'O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:63:\"https://downloads.wordpress.org/release/zh_CN/wordpress-3.9.zip\";s:6:\"locale\";s:5:\"zh_CN\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:63:\"https://downloads.wordpress.org/release/zh_CN/wordpress-3.9.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:3:\"3.9\";s:7:\"version\";s:3:\"3.9\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"3.8\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-3.9.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-3.9.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:3:\"3.9\";s:7:\"version\";s:3:\"3.9\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"3.8\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1399440892;s:15:\"version_checked\";s:3:\"3.9\";s:12:\"translations\";a:0:{}}',	'yes'),
(99,	'_site_transient_update_plugins',	'O:8:\"stdClass\":3:{s:12:\"last_checked\";i:1399440905;s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}',	'yes'),
(100,	'_site_transient_timeout_theme_roots',	'1399441804',	'yes'),
(101,	'_site_transient_theme_roots',	'a:3:{s:14:\"twentyfourteen\";s:7:\"/themes\";s:14:\"twentythirteen\";s:7:\"/themes\";s:12:\"twentytwelve\";s:7:\"/themes\";}',	'yes'),
(102,	'_site_transient_update_themes',	'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1399440909;s:7:\"checked\";a:3:{s:14:\"twentyfourteen\";s:3:\"1.0\";s:14:\"twentythirteen\";s:3:\"1.1\";s:12:\"twentytwelve\";s:3:\"1.3\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}',	'yes'),
(103,	'_site_transient_timeout_browser_0f5d8990db4df2d31f9107f57dccea47',	'1400044809',	'yes'),
(104,	'_site_transient_browser_0f5d8990db4df2d31f9107f57dccea47',	'a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"28.0\";s:10:\"update_url\";s:23:\"http://www.firefox.com/\";s:7:\"img_src\";s:50:\"http://s.wordpress.org/images/browsers/firefox.png\";s:11:\"img_src_ssl\";s:49:\"https://wordpress.org/images/browsers/firefox.png\";s:15:\"current_version\";s:2:\"16\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}',	'yes'),
(105,	'can_compress_scripts',	'1',	'yes'),
(106,	'theme_mods_twentyfourteen',	'a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1399440046;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}',	'yes'),
(107,	'current_theme',	'Twenty Twelve',	'yes'),
(108,	'theme_mods_twentytwelve',	'a:1:{i:0;b:0;}',	'yes'),
(109,	'theme_switched',	'',	'yes'),
(134,	'_transient_is_multi_author',	'0',	'yes');

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1,	2,	'_wp_page_template',	'default'),
(2,	6,	'_edit_last',	'1'),
(3,	6,	'_edit_lock',	'1399446585:1'),
(4,	6,	'_wp_page_template',	'default'),
(5,	10,	'_edit_last',	'1'),
(6,	10,	'_edit_lock',	'1399441843:1'),
(7,	10,	'_wp_page_template',	'page-tmp-capstoneproject.php'),
(8,	13,	'_edit_last',	'1'),
(9,	13,	'_edit_lock',	'1399445862:1'),
(10,	13,	'_wp_page_template',	'default'),
(11,	15,	'_edit_last',	'1'),
(12,	15,	'_edit_lock',	'1399441924:1'),
(13,	15,	'_wp_page_template',	'page-tmp-enduringunderstandings.php'),
(14,	17,	'_edit_last',	'1'),
(15,	17,	'_edit_lock',	'1399446775:1'),
(16,	17,	'_wp_page_template',	'page-tmp-project.php');

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1,	1,	'2014-05-07 05:19:35',	'2014-05-07 05:19:35',	'欢迎使用WordPress。这是系统自动生成的演示文章。编辑或者删除它，然后开始您的博客！',	'世界，你好！',	'',	'publish',	'open',	'open',	'',	'hello-world',	'',	'',	'2014-05-07 05:19:35',	'2014-05-07 05:19:35',	'',	0,	'http://localhost/wordpress/?p=1',	0,	'post',	'',	1),
(2,	1,	'2014-05-07 05:19:35',	'2014-05-07 05:19:35',	'这是示范页面。页面和博客文章不同，它的位置是固定的，通常会在站点导航栏显示。很多用户都创建一个“关于”页面，向访客介绍自己。例如，个人博客通常有类似这样的介绍：\n\n<blockquote>欢迎！我白天是个邮递员，晚上就是个有抱负的演员。这是我的博客。我住在天朝的帝都，有条叫做杰克的狗。</blockquote>\n\n……公司博客可以这样写：\n\n<blockquote>XYZ Doohickey公司成立于1971年，自从建立以来，我们一直向社会贡献着优秀doohicky。我们的公司总部位于天朝魔都，有着超过两千名员工，对魔都政府税收有着巨大贡献。</blockquote>\n\n您可以访问<a href=\"http://localhost/wordpress/wp-admin/\">仪表盘</a>，删除本页面，然后添加您自己的内容。祝您使用愉快！',	'示例页面',	'',	'publish',	'open',	'open',	'',	'sample-page',	'',	'',	'2014-05-07 05:19:35',	'2014-05-07 05:19:35',	'',	0,	'http://localhost/wordpress/?page_id=2',	0,	'page',	'',	0),
(3,	1,	'2014-05-07 13:20:10',	'0000-00-00 00:00:00',	'',	'自动草稿',	'',	'auto-draft',	'open',	'open',	'',	'',	'',	'',	'2014-05-07 13:20:10',	'0000-00-00 00:00:00',	'',	0,	'http://localhost/wordpress/?p=3',	0,	'post',	'',	0),
(4,	1,	'2014-05-07 13:21:03',	'0000-00-00 00:00:00',	'',	'自动草稿',	'',	'auto-draft',	'open',	'open',	'',	'',	'',	'',	'2014-05-07 13:21:03',	'0000-00-00 00:00:00',	'',	0,	'http://localhost/wordpress/?page_id=4',	0,	'page',	'',	0),
(5,	1,	'2014-05-07 13:22:04',	'0000-00-00 00:00:00',	'',	'自动草稿',	'',	'auto-draft',	'open',	'open',	'',	'',	'',	'',	'2014-05-07 13:22:04',	'0000-00-00 00:00:00',	'',	0,	'http://localhost/wordpress/?page_id=5',	0,	'page',	'',	0),
(6,	1,	'2014-05-07 13:34:47',	'2014-05-07 05:34:47',	'Want to bring an original and authentic project and secure global workspace to your students? Leave the lesson planning\r\nto us and join our ePals Junior Folklorist collaborative project.\r\nOur master teachers have create a complete end-to-end experience to guide your students on their journey, All you have to do is sign your students up and give them access to computers for an hour each week. It’s fun, free and easy to use! ePals provides:\r\n<ul class=\"dscription_ul\">\r\n<li>Newly-designed safe and secure, interactive and persisent woekspace</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Multiple interactive co-creation digital tools</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Communication tools including video messages</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Similar-age classroom parent(s) around the globe</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Online collaborative learning</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Outside of class fieldwork assignments</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Standards-aligned instructional plans and multi-media resources</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Active facilitation from our master teachers</li>\r\n</ul>\r\nePals knows that your time is valuable and limited. Enroll in our Collaborative Project and we’ll deliver meaningful and quality learning experiences.',	'Description',	'',	'publish',	'open',	'open',	'',	'description',	'',	'',	'2014-05-07 15:11:35',	'2014-05-07 07:11:35',	'',	0,	'http://localhost/wordpress/?page_id=6',	0,	'page',	'',	0),
(7,	1,	'2014-05-07 13:32:34',	'2014-05-07 05:32:34',	'Want to bring an original and authentic project and secure global workspace to your students? Leave the lesson planning\r\n\r\nto us and join our ePals Junior Folklorist collaborative project.\r\n\r\nOur master teachers have create a complete end-to-end experience to guide your students on their journey, All you have to do is sign your students up and give them access to computers for an hour each week. It’s fun, free and easy to use! ePals provides:\r\n&lt;ul class=\"dscription_ul\"&gt;\r\n&lt;li&gt;Newly-designed safe and secure, interactive and persisent woekspace&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;ul class=\"dscription_ul\"&gt;\r\n&lt;li&gt;Multiple interactive co-creation digital tools&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;ul class=\"dscription_ul\"&gt;\r\n&lt;li&gt;Communication tools including video messages&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;ul class=\"dscription_ul\"&gt;\r\n&lt;li&gt;Similar-age classroom parent(s) around the globe&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;ul class=\"dscription_ul\"&gt;\r\n&lt;li&gt;Online collaborative learning&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;ul class=\"dscription_ul\"&gt;\r\n&lt;li&gt;Outside of class fieldwork assignments&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;ul class=\"dscription_ul\"&gt;\r\n&lt;li&gt;Standards-aligned instructional plans and multi-media resources&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;ul class=\"dscription_ul\"&gt;\r\n&lt;li&gt;Active facilitation from our master teachers&lt;/li&gt;\r\n&lt;/ul&gt;\r\nePals knows that your time is valuable and limited. Enroll in our Collaborative Project and we’ll deliver meaningful and quality learning experiences.',	'Description-white',	'',	'inherit',	'open',	'open',	'',	'6-revision-v1',	'',	'',	'2014-05-07 13:32:34',	'2014-05-07 05:32:34',	'',	6,	'http://localhost/wordpress/?p=7',	0,	'revision',	'',	0),
(8,	1,	'2014-05-07 13:33:43',	'2014-05-07 05:33:43',	'Want to bring an original and authentic project and secure global workspace to your students? Leave the lesson planning\r\n\r\nto us and join our ePals Junior Folklorist collaborative project.\r\n\r\nOur master teachers have create a complete end-to-end experience to guide your students on their journey, All you have to do is sign your students up and give them access to computers for an hour each week. It’s fun, free and easy to use! ePals provides:\r\n<ul class=\"dscription_ul\">\r\n<li>Newly-designed safe and secure, interactive and persisent woekspace</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Multiple interactive co-creation digital tools</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Communication tools including video messages</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Similar-age classroom parent(s) around the globe</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Online collaborative learning</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Outside of class fieldwork assignments</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Standards-aligned instructional plans and multi-media resources</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Active facilitation from our master teachers</li>\r\n</ul>\r\nePals knows that your time is valuable and limited. Enroll in our Collaborative Project and we’ll deliver meaningful and quality learning experiences.',	'Description-white',	'',	'inherit',	'open',	'open',	'',	'6-revision-v1',	'',	'',	'2014-05-07 13:33:43',	'2014-05-07 05:33:43',	'',	6,	'http://localhost/wordpress/?p=8',	0,	'revision',	'',	0),
(9,	1,	'2014-05-07 13:34:47',	'2014-05-07 05:34:47',	'Want to bring an original and authentic project and secure global workspace to your students? Leave the lesson planning\r\n\r\nto us and join our ePals Junior Folklorist collaborative project.\r\n\r\nOur master teachers have create a complete end-to-end experience to guide your students on their journey, All you have to do is sign your students up and give them access to computers for an hour each week. It’s fun, free and easy to use! ePals provides:\r\n<ul class=\"dscription_ul\">\r\n<li>Newly-designed safe and secure, interactive and persisent woekspace</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Multiple interactive co-creation digital tools</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Communication tools including video messages</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Similar-age classroom parent(s) around the globe</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Online collaborative learning</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Outside of class fieldwork assignments</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Standards-aligned instructional plans and multi-media resources</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Active facilitation from our master teachers</li>\r\n</ul>\r\nePals knows that your time is valuable and limited. Enroll in our Collaborative Project and we’ll deliver meaningful and quality learning experiences.',	'Description',	'',	'inherit',	'open',	'open',	'',	'6-revision-v1',	'',	'',	'2014-05-07 13:34:47',	'2014-05-07 05:34:47',	'',	6,	'http://localhost/wordpress/?p=9',	0,	'revision',	'',	0),
(10,	1,	'2014-05-07 13:38:00',	'2014-05-07 05:38:00',	'<div class=\"capstone-project\">\r\n    <div class=\"head-line-green\"></div>\r\n    \r\n    <div class=\"cp-title\">\r\n        <font>Capstone Project</font>\r\n    </div>\r\n    <div class=\"cp-main\">\r\n        <div class=\"cp-item\">\r\n            <div class=\"cp-item-title\">\r\n                Lorem Ipsum somthing here\r\n            </div>\r\n            <div class=\"cp-item-content\">\r\n                Lorem Ipsum doror sit amet ,consectetuer adipcing elit ,sed diam nommny nibh eusismod\r\n                tincindunt ut .. <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n            </div>\r\n        </div>\r\n        \r\n        <div class=\"cp-line\"></div>\r\n        \r\n        <div class=\"cp-item\">\r\n            <div class=\"cp-item-pic\">\r\n                <img src=\"http://localhost/wordpress/images/pic.png\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title\">\r\n                    Somthing whith a image\r\n                </div>\r\n                <div class=\"cp-item-content\">\r\n                    Lorem Ipsum doror sit amet ,consectetuer adipcing elit ,sed diam nommny nibh eusismod\r\n                    tincindunt ut .. <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n        \r\n        <div class=\"cp-line\"></div>\r\n        \r\n        <div class=\"cp-item\">\r\n            <div class=\"cp-item-title\">\r\n                Ipusm Dolor again somthing here\r\n            </div>\r\n            <div class=\"cp-item-content\">\r\n                Lorem Ipsum doror sit amet ,consectetuer adipcing elit ,sed diam nommny nibh eusismod\r\n                tincindunt ut .. <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"button-div\">\r\n        <img src=\"http://localhost/wordpress/images/btn-viewall-green.png\">\r\n    </div>\r\n</div>',	'Capstone Project',	'',	'publish',	'open',	'open',	'',	'capstone-project',	'',	'',	'2014-05-07 13:52:54',	'2014-05-07 05:52:54',	'',	0,	'http://localhost/wordpress/?page_id=10',	0,	'page',	'',	0),
(11,	1,	'2014-05-07 13:36:46',	'2014-05-07 05:36:46',	'<div class=\"capstone-project\">\r\n    <div class=\"head-line-green\"></div>\r\n    \r\n    <div class=\"cp-title\">\r\n        <font>Capstone Project</font>\r\n    </div>\r\n    <div class=\"cp-main\">\r\n        <div class=\"cp-item\">\r\n            <div class=\"cp-item-title\">\r\n                Lorem Ipsum somthing here\r\n            </div>\r\n            <div class=\"cp-item-content\">\r\n                Lorem Ipsum doror sit amet ,consectetuer adipcing elit ,sed diam nommny nibh eusismod\r\n                tincindunt ut .. <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n            </div>\r\n        </div>\r\n        \r\n        <div class=\"cp-line\"></div>\r\n        \r\n        <div class=\"cp-item\">\r\n            <div class=\"cp-item-pic\">\r\n                <img src=\"http://localhost/wordpress/images/pic.png\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title\">\r\n                    Somthing whith a image\r\n                </div>\r\n                <div class=\"cp-item-content\">\r\n                    Lorem Ipsum doror sit amet ,consectetuer adipcing elit ,sed diam nommny nibh eusismod\r\n                    tincindunt ut .. <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n        \r\n        <div class=\"cp-line\"></div>\r\n        \r\n        <div class=\"cp-item\">\r\n            <div class=\"cp-item-title\">\r\n                Ipusm Dolor again somthing here\r\n            </div>\r\n            <div class=\"cp-item-content\">\r\n                Lorem Ipsum doror sit amet ,consectetuer adipcing elit ,sed diam nommny nibh eusismod\r\n                tincindunt ut .. <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"button-div\">\r\n        <img src=\"http://localhost/wordpress/images/btn-viewall-green.png\">\r\n    </div>\r\n</div>',	'Essential questions',	'',	'inherit',	'open',	'open',	'',	'10-revision-v1',	'',	'',	'2014-05-07 13:36:46',	'2014-05-07 05:36:46',	'',	10,	'http://localhost/wordpress/?p=11',	0,	'revision',	'',	0),
(12,	1,	'2014-05-07 13:38:00',	'2014-05-07 05:38:00',	'<div class=\"capstone-project\">\r\n    <div class=\"head-line-green\"></div>\r\n    \r\n    <div class=\"cp-title\">\r\n        <font>Capstone Project</font>\r\n    </div>\r\n    <div class=\"cp-main\">\r\n        <div class=\"cp-item\">\r\n            <div class=\"cp-item-title\">\r\n                Lorem Ipsum somthing here\r\n            </div>\r\n            <div class=\"cp-item-content\">\r\n                Lorem Ipsum doror sit amet ,consectetuer adipcing elit ,sed diam nommny nibh eusismod\r\n                tincindunt ut .. <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n            </div>\r\n        </div>\r\n        \r\n        <div class=\"cp-line\"></div>\r\n        \r\n        <div class=\"cp-item\">\r\n            <div class=\"cp-item-pic\">\r\n                <img src=\"http://localhost/wordpress/images/pic.png\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title\">\r\n                    Somthing whith a image\r\n                </div>\r\n                <div class=\"cp-item-content\">\r\n                    Lorem Ipsum doror sit amet ,consectetuer adipcing elit ,sed diam nommny nibh eusismod\r\n                    tincindunt ut .. <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n        \r\n        <div class=\"cp-line\"></div>\r\n        \r\n        <div class=\"cp-item\">\r\n            <div class=\"cp-item-title\">\r\n                Ipusm Dolor again somthing here\r\n            </div>\r\n            <div class=\"cp-item-content\">\r\n                Lorem Ipsum doror sit amet ,consectetuer adipcing elit ,sed diam nommny nibh eusismod\r\n                tincindunt ut .. <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"button-div\">\r\n        <img src=\"http://localhost/wordpress/images/btn-viewall-green.png\">\r\n    </div>\r\n</div>',	'Capstone Project',	'',	'inherit',	'open',	'open',	'',	'10-revision-v1',	'',	'',	'2014-05-07 13:38:00',	'2014-05-07 05:38:00',	'',	10,	'http://localhost/wordpress/?p=12',	0,	'revision',	'',	0),
(13,	1,	'2014-05-07 13:40:14',	'2014-05-07 05:40:14',	'<div class=\"capstone-project\">\r\n    <div class=\"head-line-orange\"></div>\r\n    \r\n    <div class=\"cp-title\">\r\n        <font>Essential questions</font>\r\n    </div>\r\n    <div class=\"cp-main\">\r\n        <div class=\"cp-item-org\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no1.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you identify a tradition that is enduring in your community?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item-org\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no2.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you connect with and learn from an experienced tradition bearer?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item-org\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no3.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you conduct and document a purposeful interview where the tradition bearer practices the tradition?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item-org\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no4.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you review and interpret firldwork materials to tell accurate and engaging story?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item-org\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no5.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you best present and preserve the tradition?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n    </div>\r\n\r\n\r\n    <div class=\"button-div\">\r\n        <img src=\"http://localhost/wordpress/images/learnmore.png\">\r\n    </div>\r\n</div>\r\n',	'Essential questions',	'',	'publish',	'open',	'open',	'',	'essential-questions',	'',	'',	'2014-05-07 14:57:40',	'2014-05-07 06:57:40',	'',	0,	'http://localhost/wordpress/?page_id=13',	0,	'page',	'',	0),
(14,	1,	'2014-05-07 13:39:24',	'2014-05-07 05:39:24',	'<div class=\"capstone-project\">\r\n    <div class=\"head-line-orange\"></div>\r\n    \r\n    <div class=\"cp-title\">\r\n        <font>Essential questions</font>\r\n    </div>\r\n    <div class=\"cp-main\">\r\n        <div class=\"cp-item\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no1.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you identify a tradition that is enduring in your community?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no2.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you connect with and learn from an experienced tradition bearer?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no3.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you conduct and document a purposeful interview where the tradition bearer practices the tradition?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no4.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you review and interpret firldwork materials to tell accurate and engaging story?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no5.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you best present and preserve the tradition?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n    </div>\r\n\r\n\r\n    <div class=\"button-div\">\r\n        <img src=\"http://localhost/wordpress/images/learnmore.png\">\r\n    </div>\r\n</div>\r\n',	'Essential questions',	'',	'inherit',	'open',	'open',	'',	'13-revision-v1',	'',	'',	'2014-05-07 13:39:24',	'2014-05-07 05:39:24',	'',	13,	'http://localhost/wordpress/?p=14',	0,	'revision',	'',	0),
(15,	1,	'2014-05-07 13:42:34',	'2014-05-07 05:42:34',	'<div class=\"capstone-project\">\r\n    <div class=\"head-line-blue\"></div>\r\n    \r\n    <div class=\"cp-title\">\r\n        <font>Enduring understandings</font>\r\n    </div>\r\n    <div class=\"cp-main\">\r\n        <div class=\"cp-item\">\r\n\r\n            <div class=\"cp-item-pic\">\r\n                <img src=\"http://localhost/wordpress/images/pic.png\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title\">\r\n                    \r\n                </div>\r\n                <div class=\"cp-item-content\">\r\n                   Understanding that each group has enduring traditions that are\r\n                    passed from generation to generation by tradition bearers.\r\n                    <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n        \r\n        <div class=\"cp-line\"></div>\r\n        \r\n        <div class=\"cp-item\">\r\n            <div class=\"cp-item-pic\">\r\n                <img src=\"http://localhost/wordpress/images/pic2.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title\">\r\n                    \r\n                </div>\r\n                <div class=\"cp-item-content\">\r\n                    Understanding the processes that a folking follows when studing folklore.. <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n        \r\n\r\n        \r\n\r\n    </div>\r\n\r\n    <div class=\"button-div\">\r\n        <img src=\"http://localhost/wordpress/images/btn-viewall-blue.PNG\">\r\n    </div>\r\n</div>',	'Enduring understandings',	'',	'publish',	'open',	'open',	'',	'enduring-understandings',	'',	'',	'2014-05-07 13:53:49',	'2014-05-07 05:53:49',	'',	0,	'http://localhost/wordpress/?page_id=15',	0,	'page',	'',	0),
(16,	1,	'2014-05-07 13:40:52',	'2014-05-07 05:40:52',	'<div class=\"capstone-project\">\r\n    <div class=\"head-line-blue\"></div>\r\n    \r\n    <div class=\"cp-title\">\r\n        <font>Enduring understandings</font>\r\n    </div>\r\n    <div class=\"cp-main\">\r\n        <div class=\"cp-item\">\r\n\r\n            <div class=\"cp-item-pic\">\r\n                <img src=\"http://localhost/wordpress/images/pic.png\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title\">\r\n                    \r\n                </div>\r\n                <div class=\"cp-item-content\">\r\n                   Understanding that each group has enduring traditions that are\r\n                    passed from generation to generation by tradition bearers.\r\n                    <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n        \r\n        <div class=\"cp-line\"></div>\r\n        \r\n        <div class=\"cp-item\">\r\n            <div class=\"cp-item-pic\">\r\n                <img src=\"http://localhost/wordpress/images/pic2.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title\">\r\n                    \r\n                </div>\r\n                <div class=\"cp-item-content\">\r\n                    Understanding the processes that a folking follows when studing folklore.. <a href=\"#\" class=\"cp-href-blue\">read more..</a>\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n        \r\n\r\n        \r\n\r\n    </div>\r\n\r\n    <div class=\"button-div\">\r\n        <img src=\"http://localhost/wordpress/images/btn-viewall-blue.PNG\">\r\n    </div>\r\n</div>',	'Enduring understandings',	'',	'inherit',	'open',	'open',	'',	'15-revision-v1',	'',	'',	'2014-05-07 13:40:52',	'2014-05-07 05:40:52',	'',	15,	'http://localhost/wordpress/?p=16',	0,	'revision',	'',	0),
(17,	1,	'2014-05-07 13:47:54',	'2014-05-07 05:47:54',	'',	'project view page',	'',	'publish',	'open',	'open',	'',	'project-view-page',	'',	'',	'2014-05-07 14:22:03',	'2014-05-07 06:22:03',	'',	0,	'http://localhost/wordpress/?page_id=17',	0,	'page',	'',	0),
(18,	1,	'2014-05-07 13:47:05',	'2014-05-07 05:47:05',	'',	'project view page',	'',	'inherit',	'open',	'open',	'',	'17-revision-v1',	'',	'',	'2014-05-07 13:47:05',	'2014-05-07 05:47:05',	'',	17,	'http://localhost/wordpress/?p=18',	0,	'revision',	'',	0),
(19,	1,	'2014-05-07 14:03:31',	'0000-00-00 00:00:00',	'',	'自动草稿',	'',	'auto-draft',	'open',	'open',	'',	'',	'',	'',	'2014-05-07 14:03:31',	'0000-00-00 00:00:00',	'',	0,	'http://localhost/wordpress/?page_id=19',	0,	'page',	'',	0),
(38,	1,	'2014-05-07 14:57:09',	'2014-05-07 06:57:09',	'<div class=\"capstone-project\">\n    <div class=\"head-line-orange\"></div>\n    \n    <div class=\"cp-title\">\n        <font>Essential questions</font>\n    </div>\n    <div class=\"cp-main\">\n        <div class=\"cp-item-org\">\n\n            <div class=\"cp-item-pic1\">\n                <img src=\"http://localhost/wordpress/images/lm-no1.PNG\">\n            </div>\n            <div class=\"cp-item-text\">\n                <div class=\"cp-item-title1\">\n                  How do you identify a tradition that is enduring in your community?\n                </div>\n            </div>\n            <div style=\"clear:both;\"></div>\n        </div>\n		<div class=\"cp-item-org\">\n\n            <div class=\"cp-item-pic1\">\n                <img src=\"http://localhost/wordpress/images/lm-no2.PNG\">\n            </div>\n            <div class=\"cp-item-text\">\n                <div class=\"cp-item-title1\">\n                  How do you connect with and learn from an experienced tradition bearer?\n                </div>\n            </div>\n            <div style=\"clear:both;\"></div>\n        </div>\n		<div class=\"cp-item-org\">\n\n            <div class=\"cp-item-pic1\">\n                <img src=\"http://localhost/wordpress/images/lm-no3.PNG\">\n            </div>\n            <div class=\"cp-item-text\">\n                <div class=\"cp-item-title1\">\n                  How do you conduct and document a purposeful interview where the tradition bearer practices the tradition?\n                </div>\n            </div>\n            <div style=\"clear:both;\"></div>\n        </div>\n		<div class=\"cp-item-org\">\n\n            <div class=\"cp-item-pic1\">\n                <img src=\"http://localhost/wordpress/images/lm-no4.PNG\">\n            </div>\n            <div class=\"cp-item-text\">\n                <div class=\"cp-item-title1\">\n                  How do you review and interpret firldwork materials to tell accurate and engaging story?\n                </div>\n            </div>\n            <div style=\"clear:both;\"></div>\n        </div>\n		<div class=\"cp-item\">\n\n            <div class=\"cp-item-pic1\">\n                <img src=\"http://localhost/wordpress/images/lm-no5.PNG\">\n            </div>\n            <div class=\"cp-item-text\">\n                <div class=\"cp-item-title1\">\n                  How do you best present and preserve the tradition?\n                </div>\n            </div>\n            <div style=\"clear:both;\"></div>\n        </div>\n    </div>\n\n\n    <div class=\"button-div\">\n        <img src=\"http://localhost/wordpress/images/learnmore.png\">\n    </div>\n</div>\n',	'Essential questions',	'',	'inherit',	'open',	'open',	'',	'13-autosave-v1',	'',	'',	'2014-05-07 14:57:09',	'2014-05-07 06:57:09',	'',	13,	'http://localhost/wordpress/?p=38',	0,	'revision',	'',	0),
(39,	1,	'2014-05-07 14:57:40',	'2014-05-07 06:57:40',	'<div class=\"capstone-project\">\r\n    <div class=\"head-line-orange\"></div>\r\n    \r\n    <div class=\"cp-title\">\r\n        <font>Essential questions</font>\r\n    </div>\r\n    <div class=\"cp-main\">\r\n        <div class=\"cp-item-org\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no1.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you identify a tradition that is enduring in your community?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item-org\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no2.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you connect with and learn from an experienced tradition bearer?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item-org\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no3.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you conduct and document a purposeful interview where the tradition bearer practices the tradition?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item-org\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no4.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you review and interpret firldwork materials to tell accurate and engaging story?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n		<div class=\"cp-item-org\">\r\n\r\n            <div class=\"cp-item-pic1\">\r\n                <img src=\"http://localhost/wordpress/images/lm-no5.PNG\">\r\n            </div>\r\n            <div class=\"cp-item-text\">\r\n                <div class=\"cp-item-title1\">\r\n                  How do you best present and preserve the tradition?\r\n                </div>\r\n            </div>\r\n            <div style=\"clear:both;\"></div>\r\n        </div>\r\n    </div>\r\n\r\n\r\n    <div class=\"button-div\">\r\n        <img src=\"http://localhost/wordpress/images/learnmore.png\">\r\n    </div>\r\n</div>\r\n',	'Essential questions',	'',	'inherit',	'open',	'open',	'',	'13-revision-v1',	'',	'',	'2014-05-07 14:57:40',	'2014-05-07 06:57:40',	'',	13,	'http://localhost/wordpress/?p=39',	0,	'revision',	'',	0),
(40,	1,	'2014-05-07 15:11:56',	'2014-05-07 07:11:56',	'Want to bring an original and authentic project and secure global workspace to your students? Leave the lesson planning\r\nto us and join our ePals Junior Folklorist collaborative project.\r\nOur master teachers have create a complete end-to-end experience to guide your students on their journey, All you have to do is sign your students up and give them access to computers for an hour each week. It’s fun, free and easy to use! ePals provides:\r\n<ul class=\"dscription_ul\">\r\n<li>Newly-designed safe and secure, interactive and persisent woekspace</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Multiple interactive co-creation digital tools</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Communication tools including video messages</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Similar-age classroom parent(s) around the globe</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Online collaborative learning</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Outside of class fieldwork assignments</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Standards-aligned instructional plans and multi-media resources</li>\r\n</ul>\r\n<ul class=\"dscription_ul\">\r\n<li>Active facilitation from our master teachers</li>\r\n</ul>\r\nePals knows that your time is valuable and limited. Enroll in our Collaborative Project and we’ll deliver meaningful and quality learning experiences.',	'Description',	'',	'inherit',	'open',	'open',	'',	'6-autosave-v1',	'',	'',	'2014-05-07 15:11:56',	'2014-05-07 07:11:56',	'',	6,	'http://localhost/wordpress/?p=40',	0,	'revision',	'',	0),
(43,	1,	'2014-05-07 15:13:19',	'2014-05-07 07:13:19',	'',	'project view page',	'',	'inherit',	'open',	'open',	'',	'17-autosave-v1',	'',	'',	'2014-05-07 15:13:19',	'2014-05-07 07:13:19',	'',	17,	'http://localhost/wordpress/?p=43',	0,	'revision',	'',	0);

DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1,	'未分类',	'uncategorized',	0);

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1,	1,	0);

DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1,	1,	'category',	'',	0,	1);

DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1,	1,	'first_name',	''),
(2,	1,	'last_name',	''),
(3,	1,	'nickname',	'test'),
(4,	1,	'description',	''),
(5,	1,	'rich_editing',	'true'),
(6,	1,	'comment_shortcuts',	'false'),
(7,	1,	'admin_color',	'fresh'),
(8,	1,	'use_ssl',	'0'),
(9,	1,	'show_admin_bar_front',	'true'),
(10,	1,	'wp_capabilities',	'a:1:{s:13:\"administrator\";b:1;}'),
(11,	1,	'wp_user_level',	'10'),
(12,	1,	'dismissed_wp_pointers',	'wp350_media,wp360_revisions,wp360_locks,wp390_widgets'),
(13,	1,	'show_welcome_panel',	'1'),
(14,	1,	'wp_dashboard_quick_press_last_post_id',	'3'),
(15,	1,	'wp_user-settings',	'editor=html'),
(16,	1,	'wp_user-settings-time',	'1399440885');

DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1,	'test',	'$P$BPDqEDw2m5lu4/76W9canqE/DM9Dzx0',	'test',	'11111@111.com',	'',	'2014-05-07 05:19:35',	'',	0,	'test');

-- 2014-05-07 07:26:00
